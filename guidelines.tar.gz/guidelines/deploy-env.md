# Ambiente de Despliegue (deploy-env)

Repositorio único que orquesta **imágenes versionadas en producción**.

## 🏗️ Estructura

```
deploy-env/
├── docker-compose.yml          # Orquestación de producción
├── Makefile                    # Comandos: up, down, logs, pull
├── .env                        # Versiones de imágenes + config
├── .gitignore
├── data/                       # Volúmenes (gitignored)
│   ├── postgres/
│   ├── mongo/
│   └── minio/
├── config/
│   └── nginx.conf              # Reverse proxy (opcional)
└── README.md
```

## ⚡ Principios

1. **Un único deployment**: Sin environments separados
2. **Versionado en .env**: `BACKEND_VERSION=v1.0.1`
3. **Imágenes inmutables**: Solo se deploya código compilado
4. **Propio versionado**: deploy-env tiene tags git (v1.0.0, v1.0.1, etc.)
5. **CI/CD actualiza .env**: Al cambiar versión de un servicio, commit + tag

## Archivo .env

Estructura: cada servicio con IMAGE (URL completa), VERSION, PORT

```bash
# ============================================
# BACKEND
# ============================================
BACKEND_IMAGE=registry.io/proyecto/backend
BACKEND_VERSION=v1.0.1
BACKEND_PORT=3000

# ============================================
# FRONTEND
# ============================================
FRONTEND_IMAGE=registry.io/proyecto/frontend
FRONTEND_VERSION=v1.0.0
FRONTEND_PORT=3000

# ============================================
# API GATEWAY (si aplica)
# ============================================
GATEWAY_IMAGE=registry.io/proyecto/gateway
GATEWAY_VERSION=v1.0.0
GATEWAY_PORT=8080

# ============================================
# POSTGRESQL
# ============================================
POSTGRES_IMAGE=docker.io/library/postgres:16-alpine
POSTGRES_PORT=5432
POSTGRES_USER=postgres
POSTGRES_PASSWORD=STRONG_PRODUCTION_PASSWORD
POSTGRES_DB=app_db_prod

# ============================================
# MONGODB
# ============================================
MONGO_IMAGE=docker.io/library/mongo:7
MONGO_PORT=27017
MONGO_USER=root
MONGO_PASSWORD=STRONG_PRODUCTION_PASSWORD
MONGO_DB=app_db_prod

# ============================================
# APLICACIÓN
# ============================================
NODE_ENV=production
JWT_SECRET=STRONG_PRODUCTION_JWT_SECRET
LOG_LEVEL=error

# ============================================
# LOGGING - Rotación de Logs
# ============================================
# max-size: Tamaño máximo antes de rotar (10m = 10MB)
# max-file: Cantidad máxima de archivos de log rotados (3 = mantener 3 archivos)
LOG_MAX_SIZE=10m
LOG_MAX_FILE=3
```

## Docker Compose

```yaml
version: '3.8'

services:
  backend:
    image: ${BACKEND_IMAGE}:${BACKEND_VERSION}
    restart: unless-stopped
    ports:
      - "${BACKEND_PORT}:3000"
    environment:
      - NODE_ENV=${NODE_ENV}
      - DATABASE_HOST=${DATABASE_HOST}
      - DATABASE_PORT=${DATABASE_PORT}
      - DATABASE_USER=${DATABASE_USER}
      - DATABASE_PASSWORD=${DATABASE_PASSWORD}
      - DATABASE_NAME=${DATABASE_NAME}
      - JWT_SECRET=${JWT_SECRET}
      - LOG_LEVEL=${LOG_LEVEL}
    depends_on:
      postgres:
        condition: service_healthy
      mongo:
        condition: service_healthy
    healthcheck:
      test: ["CMD", "curl", "-f", "http://localhost:3000/health"]
      interval: 30s
      timeout: 10s
      retries: 3
      start_period: 40s
    logging:
      driver: "json-file"
      options:
        max-size: ${LOG_MAX_SIZE}
        max-file: ${LOG_MAX_FILE}
        labels: "service=backend"

  frontend:
    image: ${FRONTEND_IMAGE}:${FRONTEND_VERSION}
    restart: unless-stopped
    ports:
      - "${FRONTEND_PORT}:3000"
    environment:
      - REACT_APP_API_URL=https://api.myapp.com
      - REACT_APP_ENV=${NODE_ENV}
    depends_on:
      - backend
    healthcheck:
      test: ["CMD", "curl", "-f", "http://localhost:3000/"]
      interval: 30s
      timeout: 10s
      retries: 3
    logging:
      driver: "json-file"
      options:
        max-size: ${LOG_MAX_SIZE}
        max-file: ${LOG_MAX_FILE}
        labels: "service=frontend"

  postgres:
    image: ${POSTGRES_IMAGE}
    restart: unless-stopped
    ports:
      - "${POSTGRES_PORT}:5432"
    environment:
      - POSTGRES_USER=${POSTGRES_USER}
      - POSTGRES_PASSWORD=${POSTGRES_PASSWORD}
      - POSTGRES_DB=${POSTGRES_DB}
    volumes:
      - postgres_data:/var/lib/postgresql/data
    healthcheck:
      test: ["CMD-SHELL", "pg_isready -U ${POSTGRES_USER}"]
      interval: 10s
      timeout: 5s
      retries: 5
    logging:
      driver: "json-file"
      options:
        max-size: ${LOG_MAX_SIZE}
        max-file: ${LOG_MAX_FILE}
        labels: "service=postgres"

  mongo:
    image: ${MONGO_IMAGE}
    restart: unless-stopped
    ports:
      - "${MONGO_PORT}:27017"
    environment:
      - MONGO_INITDB_ROOT_USERNAME=${MONGO_USER}
      - MONGO_INITDB_ROOT_PASSWORD=${MONGO_PASSWORD}
      - MONGO_INITDB_DATABASE=${MONGO_DB}
    volumes:
      - mongo_data:/data/db
    healthcheck:
      test: echo 'db.runCommand("ping").ok' | mongosh localhost:27017/test --quiet
      interval: 10s
      timeout: 5s
      retries: 5
    logging:
      driver: "json-file"
      options:
        max-size: ${LOG_MAX_SIZE}
        max-file: ${LOG_MAX_FILE}
        labels: "service=mongo"

volumes:
  postgres_data:
    driver: local
  mongo_data:
    driver: local
```

**Nota**: Docker Compose crea una red default automáticamente

## Makefile

```makefile
.DEFAULT_GOAL := help

.PHONY: help up down restart logs logs-backend logs-frontend status pull-images

help:
	@echo "Comandos disponibles:"
	@echo "  make up                - Desplegar servicios"
	@echo "  make down              - Bajar servicios"
	@echo "  make restart           - Reiniciar"
	@echo "  make status            - Ver estado de servicios"
	@echo "  make logs              - Ver todos los logs"
	@echo "  make logs-backend      - Ver logs del backend"
	@echo "  make logs-frontend     - Ver logs del frontend"
	@echo "  make pull-images       - Descargar imágenes desde registry"

status:
	@docker compose ps

up:
	@echo "🚀 Desplegando servicios..."
	@echo "Versiones en uso:"
	@grep "_VERSION=" .env | grep -v "^#"
	@docker compose up -d
	@echo "✅ Servicios desplegados"

down:
	@echo "⏹️  Bajando servicios..."
	@docker compose down --remove-orphans
	@echo "✅ Servicios bajados"

restart: down up

logs:
	@docker compose logs -f

logs-backend:
	@docker compose logs -f backend

logs-frontend:
	@docker compose logs -f frontend

pull-images:
	@echo "📥 Descargando imágenes..."
	@docker compose pull
	@echo "✅ Imágenes actualizadas"
```

## Cómo Actualizar Versiones

### CI/CD Trigger (Automático)

Cuando un servicio (ej: backend) pushea a rama `dev`:

1. **En backend repo**: CI/CD calcula versión (v1.0.1) y pushea imagen
2. **Trigger webhook**: Ejecuta en deploy-env repo
   ```bash
   # Actualizar .env
   sed -i "s/BACKEND_VERSION=.*/BACKEND_VERSION=v1.0.1/" .env

   # Commit
   git add .env
   git commit -m "Update backend to v1.0.1"

   # Tag del deploy-env (versionado propio)
   git tag -a v1.2.0 -m "Release v1.2.0 - backend v1.0.1"
   git push && git push --tags
   ```

3. **Resultado**: deploy-env tiene su propio tag (v1.2.0) que incluye todos los cambios

### Manual (Si es necesario)

```bash
# Editar .env
vim .env

# Cambiar versión
BACKEND_VERSION=v1.0.1
FRONTEND_VERSION=v1.0.5

# Commit y tag
git add .env
git commit -m "Update backend to v1.0.1, frontend to v1.0.5"
git tag -a v1.2.0 -m "Release v1.2.0"
git push && git push --tags

# Desplegar
make pull-images
make up

# Verificar qué se desplegó
grep "_VERSION=" .env
```

## Desplegar en Test

```bash
# Ver tags disponibles
git tag | sort -V

# Checkout a versión específica
git checkout v1.1.0

# Desplegar esa versión
make pull-images
make up

# Ver qué versiones está corriendo
grep VERSION .env
```

## Rollback

```bash
# Volver a versión anterior
git checkout v1.0.0

# Desplegar
make pull-images
make up
```

## Clonación y Setup

```bash
# Clonar
git clone <repo_url>/deploy-env.git
cd deploy-env

# Desplegar (descarga imágenes automáticamente)
make pull-images
make up

# Verificar estado
make status
make logs
```

## .gitignore

```
.env
data/
*.log
.vscode/
.idea/
.DS_Store
```

## README.md Mínimo

```markdown
# Deploy Environment

Orquestación de servicios en producción.

## Quick Start

\`\`\`bash
git clone <repo_url>/deploy-env.git
cd deploy-env

# Desplegar
make pull-images
make up

# Ver estado
make status
\`\`\`

## Actualizar Versión

\`\`\`bash
vim .env
# Cambiar: BACKEND_VERSION=v1.0.1

git add .env
git commit -m "Update backend to v1.0.1"
git tag -a v1.2.0 -m "Release v1.2.0"
git push && git push --tags

make pull-images
make up
\`\`\`

## Desplegar en Test

\`\`\`bash
# Listar versiones
git tag

# Desplegar versión específica
git checkout v1.1.0
make up

# Volver a latest
git checkout main
make up
\`\`\`

## Versiones

Versiones de deploy-env: v1.0.0, v1.1.0, v1.2.0, etc.
Cada tag incluye las versiones de servicios en ese momento.

\`\`\`bash
# Ver qué servicios hay en cada versión
git show v1.2.0:.env | grep VERSION
\`\`\`
```

## Versionado de deploy-env

### Estrategia

`deploy-env` tiene su propio versionado independiente:

```
v1.0.0    # Release inicial
v1.0.1    # Bug fix en frontend
v1.1.0    # Actualización de backend
v1.2.0    # Múltiples cambios
```

### Historial

Cada tag es un snapshot completo:

```bash
# Ver estado en v1.1.0
git checkout v1.1.0
cat .env | grep VERSION

# Ver cambios entre versiones
git diff v1.0.0 v1.1.0 -- .env
```

## Checklist

- [ ] docker-compose.yml usa variables para todas las versiones
- [ ] .env existe con versiones de todos los servicios
- [ ] Makefile tiene: up, down, status, logs, pull-images
- [ ] data/ está en .gitignore
- [ ] README documenta cómo desplegar y actualizar
- [ ] Deploy-env tiene su propio versionado con tags
- [ ] Health checks configurados en docker-compose
- [ ] Volúmenes nombrados para persistencia
