# Guía para Microservicios

Estructura y mejores prácticas para **cualquier microservicio** (Node, Python, Go, etc.).

## 🏗️ Estructura

```
microservicio/
├── src/                    # Código fuente
├── docker/
│   ├── dockerfile.dev      # Build para desarrollo (con devDependencies)
│   └── dockerfile.prod     # Build para producción (multi-stage)
├── Makefile               # Targets: dev-img, prod-img, push-*
├── package.json           # Dependencias
├── README.md
├── .gitignore
└── .dockerignore
```

## Dockerfiles

### Patrón: Multi-stage + Non-root user + Health check

**Node.js (dockerfile.dev)**
```dockerfile
FROM node:20-alpine
WORKDIR /app
COPY package*.json ./
RUN npm install
COPY . .
EXPOSE 3000
CMD ["npm", "run", "dev"]
```

**Node.js (dockerfile.prod)**
```dockerfile
FROM node:20-alpine AS builder
WORKDIR /build
COPY package*.json ./
RUN npm install
COPY . .
RUN npm run build

FROM node:20-alpine
WORKDIR /app
RUN addgroup -g 1001 -S nodejs && adduser -S nodejs -u 1001
COPY --from=builder /build/node_modules ./node_modules
COPY --from=builder /build/dist ./dist
COPY package*.json ./
USER nodejs
EXPOSE 3000
HEALTHCHECK --interval=30s --timeout=3s --start-period=40s --retries=3 \
  CMD node -e "require('http').get('http://localhost:3000/health', (r) => {if (r.statusCode !== 200) throw new Error()})"
CMD ["node", "dist/main"]
```

**Python (dockerfile.dev)**
```dockerfile
FROM python:3.11-alpine
WORKDIR /app
COPY requirements.txt .
RUN pip install --no-cache-dir -r requirements.txt
COPY . .
EXPOSE 8000
CMD ["uvicorn", "main:app", "--host", "0.0.0.0", "--port", "8000", "--reload"]
```

**Python (dockerfile.prod)**
```dockerfile
FROM python:3.11-alpine AS builder
WORKDIR /build
RUN apk add --no-cache gcc musl-dev python3-dev
COPY requirements.txt .
RUN pip install --user --no-cache-dir -r requirements.txt

FROM python:3.11-alpine
WORKDIR /app
RUN addgroup -g 1001 -S appuser && adduser -S appuser -u 1001
COPY --from=builder /root/.local /home/appuser/.local
COPY . .
ENV PATH=/home/appuser/.local/bin:$PATH PYTHONUNBUFFERED=1
USER appuser
EXPOSE 8000
HEALTHCHECK --interval=30s --timeout=3s --start-period=40s --retries=3 \
  CMD python -c "import urllib.request; urllib.request.urlopen('http://localhost:8000/health')" || exit 1
CMD ["uvicorn", "main:app", "--host", "0.0.0.0", "--port", "8000"]
```

**Go (dockerfile.dev)**
```dockerfile
FROM golang:1.22-alpine
WORKDIR /app
COPY go.mod go.sum ./
RUN go mod download
COPY . .
EXPOSE 8080
CMD ["go", "run", "main.go"]
```

**Go (dockerfile.prod)**
```dockerfile
FROM golang:1.22-alpine AS builder
WORKDIR /build
COPY go.mod go.sum ./
RUN go mod download
COPY . .
RUN CGO_ENABLED=0 GOOS=linux go build -ldflags="-w -s" -o app main.go

FROM alpine:latest
WORKDIR /app
RUN addgroup -g 1001 -S appuser && adduser -S appuser -u 1001
COPY --from=builder /build/app .
USER appuser
EXPOSE 8080
HEALTHCHECK --interval=30s --timeout=3s --start-period=40s --retries=3 \
  CMD wget --no-verbose --tries=1 --spider http://localhost:8080/health || exit 1
CMD ["./app"]
```

## Makefile

```makefile
.PHONY: dev-img push-dev-img prod-img push-prod-img

# Imagen dev: <IMAGE_NAME>-dev:latest (sobrescribible, manual)
dev-img:
ifndef IMAGE_NAME
	$(error Uso: make dev-img IMAGE_NAME=registry.io/proyecto/servicio)
endif
	docker buildx build --tag $(IMAGE_NAME)-dev:latest -f docker/dockerfile.dev .

push-dev-img:
ifndef IMAGE_NAME
	$(error Uso: make push-dev-img IMAGE_NAME=registry.io/proyecto/servicio)
endif
	docker push $(IMAGE_NAME)-dev:latest

# Imagen prod: <IMAGE_NAME>:vX.Y.Z (inmutable, automático en CI/CD)
prod-img:
ifndef IMAGE_NAME
	$(error Uso: make prod-img IMAGE_NAME=registry.io/proyecto/servicio VERSION=x.y.z)
endif
ifndef VERSION
	$(error VERSION es requerida: make prod-img IMAGE_NAME=... VERSION=x.y.z)
endif
	npm install --omit=dev --prefer-offline --no-audit --fund false
	docker buildx build --tag $(IMAGE_NAME):$(VERSION) -f docker/dockerfile.prod .

push-prod-img:
ifndef IMAGE_NAME
	$(error Uso: make push-prod-img IMAGE_NAME=registry.io/proyecto/servicio VERSION=x.y.z)
endif
ifndef VERSION
	$(error VERSION es requerida: make push-prod-img IMAGE_NAME=... VERSION=x.y.z)
endif
	docker push $(IMAGE_NAME):$(VERSION)
```

**Uso**:
```bash
# Desarrollo (manual)
make dev-img IMAGE_NAME=registry.io/proyecto/backend
make push-dev-img IMAGE_NAME=registry.io/proyecto/backend

# Producción (CI/CD)
make prod-img IMAGE_NAME=registry.io/proyecto/backend VERSION=v1.0.0
make push-prod-img IMAGE_NAME=registry.io/proyecto/backend VERSION=v1.0.0
```

## Versionado Semántico

```
v1.0.0    # Primera versión (MAJOR.MINOR.PATCH)
v1.0.1    # Bug fix (incrementa PATCH)
v1.1.0    # Feature nueva (incrementa MINOR, reset PATCH)
v2.0.0    # Breaking change (incrementa MAJOR)
```

## CI/CD: GitLab

El flujo automático en rama `dev`:

1. **stage_version**: Calcula siguiente versión basada en últimos tags
2. **stage_prod_img**: Construye y pushea imagen versionada

Ejemplo `.gitlab-ci.yml` (adaptado del concentrador-registros-asistencia):

```yaml
stages:
  - dev-img
  - version
  - prod-img

variables:
  BASE_IMAGE_NAME: "${HARBOR_REGISTRY}/${PROJECT_NAME}/${CI_PROJECT_NAME}"

# Manual: imagen de desarrollo
stage_dev_image:
  stage: dev-img
  rules:
    - when: manual
  tags: [docker]
  before_script:
    - echo "$REGISTRY_PASSWORD" | docker login -u "$REGISTRY_USER" -p - "$HARBOR_REGISTRY"
  script:
    - make dev-img IMAGE_NAME=${BASE_IMAGE_NAME}
    - make push-dev-img IMAGE_NAME=${BASE_IMAGE_NAME}

# Automático: calcular versión (solo rama dev)
stage_version:
  stage: version
  image: alpine:latest
  rules:
    - if: '$CI_COMMIT_BRANCH == "dev"'
  script:
    - |
      LAST_TAG=$(git tag | grep -E '^[0-9]+\.[0-9]+\.[0-9]+$' | sort -V | tail -n1 || echo "0.0.0")
      MAJOR=$(echo "$LAST_TAG" | cut -d. -f1)
      MINOR=$(echo "$LAST_TAG" | cut -d. -f2)
      PATCH=$(echo "$LAST_TAG" | cut -d. -f3)
      PATCH=$((PATCH + 1))
      NEXT_VERSION="${MAJOR}.${MINOR}.${PATCH}"

      curl --header "PRIVATE-TOKEN: ${GIT_PUSH_TOKEN}" \
        --request POST \
        "${CI_SERVER_URL}/api/v4/projects/${CI_PROJECT_ID}/repository/tags?tag_name=${NEXT_VERSION}&ref=${CI_COMMIT_SHA}"

      echo "VERSION=${NEXT_VERSION}" > version.env
  artifacts:
    reports:
      dotenv: version.env

# Automático: construir imagen versionada
stage_prod_img:
  stage: prod-img
  rules:
    - if: '$CI_COMMIT_BRANCH == "dev"'
  needs: [stage_version]
  tags: [docker]
  before_script:
    - echo "$REGISTRY_PASSWORD" | docker login -u "$REGISTRY_USER" -p - "$HARBOR_REGISTRY"
  script:
    - make prod-img IMAGE_NAME=${BASE_IMAGE_NAME} VERSION=${VERSION}
    - make push-prod-img IMAGE_NAME=${BASE_IMAGE_NAME} VERSION=${VERSION}
```

## Health Check (Obligatorio)

Todos los servicios deben exponer un endpoint `/health`:

**Node.js (NestJS)**
```typescript
@Controller('health')
export class HealthController {
  @Get()
  health() {
    return { status: 'ok' };
  }
}
```

**Python (FastAPI)**
```python
@app.get("/health")
async def health():
    return {"status": "ok"}
```

**Go (Gin)**
```go
r.GET("/health", func(c *gin.Context) {
  c.JSON(200, gin.H{"status": "ok"})
})
```

## Configuración por Variables de Entorno

**Todos los servicios DEBEN leer configuración de variables, NUNCA hardcodear**:

```bash
NODE_ENV=production          # Entorno
PORT=3000                    # Puerto interno
LOG_LEVEL=info              # Logging
DATABASE_URL=postgresql://...
JWT_SECRET=...
```

## Logging

- Salida a **stdout/stderr** (Docker captura automáticamente)
- Formato **JSON** para fácil parseo
- Niveles: debug, info, warn, error

```javascript
// Node.js
console.log(JSON.stringify({ level: 'info', msg: 'Message' }));
```

## Archivos Ignores

**.gitignore**
```
node_modules/
dist/
build/
__pycache__/
*.pyc
.venv/
.env.local
.vscode/
.idea/
.DS_Store
```

**.dockerignore**
```
node_modules/
dist/
build/
.git/
.gitignore
README.md
.env
.vscode/
.idea/
```

## Agregar Servicio al dev-env

Una vez creado el repo del microservicio:

```bash
# En el repo dev-env
git submodule add <repo-url> src/<nombre-servicio>
git config -f .gitmodules submodule.src/<nombre-servicio>.branch dev
git add .gitmodules .gitsubmodule
git commit -m "Agregar servicio <nombre-servicio>"
```

Actualizar `docker-compose.yml`:
```yaml
services:
  mi-servicio:
    image: proyecto-mi-servicio:latest
    ports:
      - "${MI_SERVICIO_PORT}:3000"
    environment:
      - NODE_ENV=${NODE_ENV}
    volumes:
      - ./src/mi-servicio:/app
      - /app/node_modules
```

Agregar en `.env`:
```bash
MI_SERVICIO_PORT=8013
```

Luego: `make init && make up`

## Checklist

- [ ] ¿Dockerfile usa multi-stage build?
- [ ] ¿Dockerfile usa non-root user?
- [ ] ¿Dockerfile incluye health check?
- [ ] ¿Makefile tiene targets: dev-img, push-dev-img, prod-img, push-prod-img?
- [ ] ¿Servicio lee variables de entorno (no hardcodeadas)?
- [ ] ¿Existe endpoint /health?
- [ ] ¿Logging va a stdout/stderr?
- [ ] ¿.gitignore y .dockerignore están correctos?
- [ ] ¿README documenta cómo correr y buildear?
