# Guidelines: Estructura de Proyectos con Microservicios

Guías para crear y mantener proyectos basados en **microservicios**.

## 🗺️ Brújula: ¿Qué documento necesito?

**¿Qué estás haciendo?** → **Lee esto:**

| Necesidad | Documento |
|-----------|-----------|
| Configurar ambiente **local** donde trabajo | [dev-env.md](./dev-env.md) |
| Crear/mejorar un **microservicio** (genérico) | [service.md](./service.md) |
| Trabajar con **NestJS** backend | [nest.md](./nest.md) |
| Desplegar en **producción/staging** | [deploy-env.md](./deploy-env.md) |

---

## 📋 Documentación Disponible

### [dev-env.md](./dev-env.md) - Ambiente de Desarrollo
Para trabajar localmente. Define:
- Estructura de carpetas del repo dev-env
- docker-compose.yml para desarrollo (con hot reload)
- Makefile con comandos útiles
- Variables de entorno (.env)
- Git submodules

### [service.md](./service.md) - Guía para Microservicios
Aplica a **cualquier servicio** (Node, Python, Go, etc.). Cubre:
- Estructura interna del microservicio
- Dockerfile optimizado (multi-stage)
- Makefile para construir imágenes
- Versionado semántico (v1.0.0)
- Health checks
- Logging

### [nest.md](./nest.md) - NestJS Específico
Si tu backend es **NestJS**. Incluye:
- Patrón ConfigService (obligatorio)
- Estructura de módulos, servicios, controllers
- DTOs y validación
- Autenticación JWT
- TypeORM y migraciones
- Swagger/documentación
- Testing

### [deploy-env.md](./deploy-env.md) - Producción y Staging
Para desplegar. Cubre:
- Estructura de repo deploy-env (único repositorio)
- docker-compose.yml para producción (con health checks y logging)
- Variables de entorno (incluyendo versionado de imágenes)
- Rotación automática de logs configurable
- Makefile para deploy/rollback
- **Cómo actualizar versiones de imágenes**
- Versionado de deploy-env con tags git

---

## 🏗️ Estructura de Proyectos

**Tres repositorios independientes:**

```
dev-env/                          ← Repo 1: Ambiente de desarrollo
├── src/                          (git submodules de cada servicio)
│   ├── backend/                  ← Apunta a repo independiente
│   ├── frontend/                 ← Apunta a repo independiente
│   └── ...
├── docker-compose.yml
├── Makefile
├── config/env.example
└── data/                         (volúmenes locales)

backend/                          ← Repo 2: Microservicio (ejemplo)
├── src/
├── Dockerfile                    ← El Dockerfile va aquí
├── Makefile                      ← Para construir imagen
├── package.json
└── ...

frontend/                         ← Repo 3: Microservicio (ejemplo)
├── src/
├── Dockerfile
├── Makefile
├── package.json
└── ...

deploy-env/                       ← Repo 4: Ambiente de producción
├── docker-compose.yml
├── Makefile
├── .env                          # Versiones de servicios (BACKEND_VERSION, FRONTEND_VERSION, etc.)
├── data/                         # Volúmenes locales
├── config/
│   └── nginx.conf               # Reverse proxy (opcional)
└── README.md
```

---

## ⚡ Conceptos Clave

### Separación de Responsabilidades
- **dev-env**: Orquesta servicios **en desarrollo** (código local, hot reload)
- **Microservicio**: Código independiente, Dockerfile incluido
- **deploy-env**: Orquesta imágenes **versionadas** en producción (immutable)

### Imágenes
- Se construyen en **cada microservicio** (en el repo del servicio)
- Se versionan **semánticamente**: v1.0.0, v1.0.1, v1.1.0, v2.0.0
- Se refieren en **deploy-env** por versión
- Nunca se editan en `dev-env` o `deploy-env`

### Dockerfiles
- Van en el repo de **cada microservicio**
- Multi-stage builds (optimizar tamaño)
- Non-root user (seguridad)
- Health checks incluidos

---

## 🚀 Flujo de Trabajo

### 1️⃣ Antes de Empezar (Primera Vez)
```bash
git clone <repo_url>/dev-env.git <nombre_proyecto>
cd <nombre_proyecto>
make init
make up
```

### 2️⃣ Durante Desarrollo
- Trabajas en `src/backend`, `src/frontend`, etc.
- Cambios aparecen inmediatamente (hot reload)
- `make logs` para debugging

### 3️⃣ Crear Nuevo Microservicio
- Lee [service.md](./service.md) para estructura genérica
- Si es NestJS, lee [nest.md](./nest.md)
- Crea repo independiente con Dockerfile
- Agrégalo como git submodule a dev-env: `git submodule add ...`

### 4️⃣ Construir Imagen para Producción
- En el repo del microservicio: `make build TAG=v1.0.0`
- Pushea a registry: `make build-push TAG=v1.0.0`

### 5️⃣ Desplegar a Producción
- CI/CD trigger actualiza `.env` en deploy-env
- Commit + tag automático en deploy-env (v1.2.0)
- Para test: `git checkout v1.1.0 && make up`
- Para rollback: `git checkout v1.0.0 && make up`

---

## ✅ Checklist para Nuevo Proyecto

### Setup Inicial
- [ ] Crear múltiples repos: dev-env, deploy-env, microservicios independientes
- [ ] dev-env tiene docker-compose.yml, Makefile, config/env.example
- [ ] Cada microservicio tiene Dockerfile, Makefile, package.json
- [ ] deploy-env tiene docker-compose.yml y .env con versiones de servicios

### Development
- [ ] `make init && make up` funciona
- [ ] Cambios en código aparecen en tiempo real
- [ ] `make logs` muestra salida útil

### Production
- [ ] Imágenes versionadas semánticamente (v1.0.0, v1.0.1, v1.1.0, etc.)
- [ ] .env documenta qué versión corre de cada servicio
- [ ] Rollback posible con `git checkout` a tag anterior y `make up`
- [ ] Health checks configurados en docker-compose.yml
- [ ] Logging configurado con rotación automática

---

## 📚 Referencias Rápidas

**Proyecto de ejemplo completo**: `/apps/modernizacion/concentrador-registros-asistencia`

**Comandos comunes**:
```bash
# Desarrollo
make init          # Primera vez
make up            # Levantar servicios
make down          # Bajar servicios
make logs          # Ver logs

# Producción
make deploy-staging       # Desplegar a staging
make deploy-production    # Desplegar a producción
make rollback-production  # Volver atrás
```

---

## ❓ Preguntas Frecuentes

**P: ¿Dónde va el Dockerfile?**
A: En el repo de cada **microservicio**, nunca en dev-env o deploy-env

**P: ¿Puedo editar imágenes en producción?**
A: No. Construye nueva versión, pushea a registry, actualiza .env en deploy-env, redeploy

**P: ¿Cómo vuelvo atrás si algo falla?**
A: En deploy-env: `git checkout <tag_anterior>` y `make up`

**P: ¿Hot reload en producción?**
A: No. Producción usa imágenes compiladas/transpiladas (immutable)

**P: ¿Qué pasa con datos en base de datos?**
A: Los volúmenes en deploy-env son persistentes. Los datos persisten a través de rollbacks

**P: ¿Cómo está versionado deploy-env?**
A: deploy-env tiene sus propios tags (v1.0.0, v1.0.1, v1.1.0). Cada tag es un snapshot del estado completo
