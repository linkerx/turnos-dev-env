# Ambiente de Desarrollo (dev-env)

Repositorio que orquesta **microservicios en desarrollo** localmente.

## 🏗️ Estructura

```
dev-env/
├── src/                           # Microservicios (git submodules)
│   ├── backend/                   # ← Repo independiente
│   ├── frontend/                  # ← Repo independiente
│   └── ...
├── docker-compose.yml
├── Makefile
├── config/env.example
├── data/                          # Volúmenes (gitignored)
├── .env                           # Variables (no en git)
├── .gitignore
├── .gitmodules
└── README.md
```

## ⚡ Reglas

1. **Dockerfiles**: Van en **cada microservicio**, no aquí
2. **Puertos**: TODOS en .env, nunca hardcodeados
3. **Submodules**: Branch default = `dev`
4. **Volúmenes**: Los datos en `data/` (gitignored)

## Archivo .env

```bash
# PUERTOS
BACKEND_PORT=8011
FRONTEND_PORT=8012
POSTGRES_PORT=5432
MONGO_PORT=27017

# POSTGRESQL
POSTGRES_USER=postgres
POSTGRES_PASSWORD=postgres
POSTGRES_DB=app_db
POSTGRES_HOST=postgres

# MONGODB
MONGO_USER=root
MONGO_PASSWORD=mongo
MONGO_DB=app_db
MONGO_HOST=mongo

# APLICACIÓN
NODE_ENV=development
ADMIN_SECRET=change_in_production
```

## Docker Compose

```yaml
version: '3.8'

services:
  backend:
    image: proyecto-backend:latest
    ports:
      - "${BACKEND_PORT}:3000"
    environment:
      - NODE_ENV=${NODE_ENV}
      - DATABASE_URL=postgresql://${POSTGRES_USER}:${POSTGRES_PASSWORD}@postgres:5432/${POSTGRES_DB}
    depends_on:
      - postgres
      - mongo
    volumes:
      - ./src/backend:/app
      - /app/node_modules

  frontend:
    image: proyecto-frontend:latest
    ports:
      - "${FRONTEND_PORT}:3000"
    environment:
      - REACT_APP_API_URL=http://localhost:${BACKEND_PORT}
    depends_on:
      - backend
    volumes:
      - ./src/frontend:/app
      - /app/node_modules

  postgres:
    image: postgres:16-alpine
    ports:
      - "${POSTGRES_PORT}:5432"
    environment:
      - POSTGRES_USER=${POSTGRES_USER}
      - POSTGRES_PASSWORD=${POSTGRES_PASSWORD}
      - POSTGRES_DB=${POSTGRES_DB}
    volumes:
      - ./data/postgres:/var/lib/postgresql/data

  mongo:
    image: mongo:7
    ports:
      - "${MONGO_PORT}:27017"
    environment:
      - MONGO_INITDB_ROOT_USERNAME=${MONGO_USER}
      - MONGO_INITDB_ROOT_PASSWORD=${MONGO_PASSWORD}
      - MONGO_INITDB_DATABASE=${MONGO_DB}
    volumes:
      - ./data/mongo:/data/db
```

## Makefile

```makefile
.DEFAULT_GOAL := help

.PHONY: help init up down restart logs logs-backend logs-frontend

help:
	@echo "make init              - Setup inicial (submodulos + deps)"
	@echo "make up                - Levantar servicios"
	@echo "make down              - Bajar servicios"
	@echo "make restart           - Reiniciar"
	@echo "make logs              - Ver todos los logs"
	@echo "make logs-backend      - Ver logs del backend"

init:
	@echo "Inicializando proyecto..."
	@if [ ! -f .env ]; then cp config/env.example .env; echo ".env creado desde config/env.example"; else echo ".env ya existe"; fi

	@echo "Reseteando submódulos..."
	git submodule foreach --recursive git reset --hard
	git submodule foreach --recursive git clean -fd
	git submodule update --init --recursive --remote

	@echo "Limpiando e instalando node_modules en submódulos..."
	@for submodule in backend frontend; do \
		echo "Procesando $$submodule..."; \
		docker compose run --rm $$submodule rm -rf node_modules package-lock.json; \
		docker compose run --rm $$submodule npm install; \
	done

	@echo "Proyecto inicializado/reseteado correctamente"

up:
	@docker compose up -d

down:
	@docker compose down --remove-orphans

restart: down up

logs:
	@docker compose logs -f

logs-backend:
	@docker compose logs -f backend

logs-frontend:
	@docker compose logs -f frontend
```

## Clonar Proyecto

```bash
# Clonar dev-env en carpeta con nombre del proyecto
git clone <repo_url>/dev-env.git <nombre_proyecto>
cd <nombre_proyecto>

# Setup inicial (descarga submodules e instala dependencias)
make init

# Levantar servicios
make up
```

## .gitignore

```
.env
data/
**/node_modules/
**/dist/
*.log
.vscode/
.idea/
.DS_Store
```

## README.md Mínimo

```markdown
# [Proyecto]

## Quick Start

\`\`\`bash
make init
make up
\`\`\`

## Servicios

- Backend: http://localhost:8011
- Frontend: http://localhost:8012
- PostgreSQL: localhost:5432
- MongoDB: localhost:27017

## Comandos

- \`make logs\` - Ver logs
- \`make restart\` - Reiniciar
- \`make down\` - Bajar servicios

## Repositorios

- Backend: [URL]
- Frontend: [URL]
```

## Checklist

- [ ] docker-compose.yml usa variables para TODOS los puertos
- [ ] config/env.example existe
- [ ] Git submodules configurados correctamente
- [ ] Makefile tiene: init, up, down, logs
- [ ] data/ está en .gitignore
- [ ] README.md documenta cómo levantar el proyecto
