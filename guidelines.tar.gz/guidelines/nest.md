# Guía NestJS

Pautas y patrones específicos para microservicios backend construidos con **NestJS**.

## Stack Recomendado

- **Runtime**: Node.js 20+
- **Framework**: NestJS 10+
- **Lenguaje**: TypeScript
- **ORM**: TypeORM (preferido)
- **Base de Datos**: PostgreSQL (preferido)
- **Documentación**: Swagger/OpenAPI
- **Testing**: Jest (incluido con NestJS)

## Estructura de Proyecto

```
backend/
├── src/
│   ├── config/           # Configuración centralizada
│   │   └── configuration.ts
│   ├── modules/          # Módulos (feature modules)
│   │   ├── users/
│   │   │   ├── users.module.ts
│   │   │   ├── users.service.ts
│   │   │   ├── users.controller.ts
│   │   │   ├── entities/
│   │   │   │   └── user.entity.ts
│   │   │   └── dto/
│   │   │       ├── create-user.dto.ts
│   │   │       └── update-user.dto.ts
│   │   ├── products/
│   │   └── [otros módulos]
│   ├── common/           # Código compartido
│   │   ├── decorators/
│   │   ├── filters/
│   │   ├── guards/
│   │   ├── interceptors/
│   │   ├── pipes/
│   │   └── middleware/
│   ├── database/         # Configuración de BD
│   │   ├── migrations/
│   │   └── seeds/
│   ├── app.module.ts
│   ├── app.controller.ts
│   ├── app.service.ts
│   └── main.ts
├── test/                 # Tests de integración
├── Dockerfile
├── Makefile
├── package.json
├── tsconfig.json
├── jest.config.js
├── .env.example
└── README.md
```

## Configuración Centralizada

### Patrón Obligatorio: Config Service

**TODOS** los microservicios NestJS DEBEN usar este patrón.

#### src/config/configuration.ts

```typescript
export const configuration = () => ({
  // Aplicación
  nodeEnv: process.env.NODE_ENV || 'development',
  // NOTA: NO incluir 'port' aquí - el puerto es fijo en 3000
  // Las variables de puerto en .env son para port forwarding de Docker al host

  // Base de datos
  database: {
    type: 'postgres' as const,
    host: process.env.DATABASE_HOST || 'postgres',
    port: parseInt(process.env.DATABASE_PORT, 10) || 5432,
    username: process.env.DATABASE_USER || 'postgres',
    password: process.env.DATABASE_PASSWORD || 'postgres',
    database: process.env.DATABASE_NAME || 'nestjs_db',
    // Sincronización automática solo en desarrollo
    synchronize: process.env.NODE_ENV !== 'production',
    logging: process.env.NODE_ENV === 'development',
    dropSchema: process.env.NODE_ENV === 'test',
  },

  // JWT / Auth
  auth: {
    jwtSecret: process.env.JWT_SECRET || 'change_me_in_production',
    jwtExpirationTime: process.env.JWT_EXPIRATION_TIME || '24h',
  },

  // MongoDB (si aplica)
  mongo: {
    uri: process.env.MONGODB_URI || 'mongodb://localhost:27017/nestjs_db',
  },

  // Logging
  logging: {
    level: process.env.LOG_LEVEL || 'info',
  },

  // Aplicación
  app: {
    name: 'API Backend',
    version: '1.0.0',
  },
});

export type Configuration = ReturnType<typeof configuration>;
```

#### src/app.module.ts

```typescript
import { Module } from '@nestjs/common';
import { ConfigModule, ConfigService } from '@nestjs/config';
import { TypeOrmModule } from '@nestjs/typeorm';
import { configuration } from './config/configuration';
import { AppController } from './app.controller';
import { AppService } from './app.service';
import { UsersModule } from './modules/users/users.module';

@Module({
  imports: [
    // Configuración global
    ConfigModule.forRoot({
      isGlobal: true,
      load: [configuration],
    }),

    // Base de datos (async para usar ConfigService)
    TypeOrmModule.forRootAsync({
      imports: [ConfigModule],
      inject: [ConfigService],
      useFactory: (configService: ConfigService) => ({
        ...configService.get('database'),
        // Entities
        entities: [
          'dist/**/*.entity{.ts,.js}',
        ],
        // Migrations
        migrations: ['dist/database/migrations/*{.ts,.js}'],
        migrationsRun: false, // Ejecutar manualmente o en seed
      }),
    }),

    // Módulos de features
    UsersModule,
    // ... otros módulos
  ],
  controllers: [AppController],
  providers: [AppService],
})
export class AppModule {}
```

#### src/main.ts

```typescript
import { NestFactory } from '@nestjs/core';
import { ValidationPipe, Logger } from '@nestjs/common';
import { SwaggerModule, DocumentBuilder } from '@nestjs/swagger';
import { AppModule } from './app.module';

async function bootstrap() {
  const app = await NestFactory.create(AppModule);
  const logger = new Logger('Bootstrap');

  // Validación global de DTOs
  app.useGlobalPipes(
    new ValidationPipe({
      whitelist: true,
      forbidNonWhitelisted: true,
      transform: true,
      transformOptions: {
        enableImplicitConversion: true,
      },
    }),
  );

  // Documentación Swagger
  const config = new DocumentBuilder()
    .setTitle('API Backend')
    .setDescription('API para gestión de recursos')
    .setVersion('1.0')
    .addBearerAuth()
    .build();
  const document = SwaggerModule.createDocument(app, config);
  SwaggerModule.setup('api/docs', app, document);

  // CORS si aplica
  app.enableCors({
    origin: process.env.CORS_ORIGIN || '*',
  });

  // Health check endpoint
  const PORT = 3000; // Puerto interno fijo
  await app.listen(PORT);
  logger.log(`Application running on: http://localhost:${PORT}`);
  logger.log(`Swagger documentation: http://localhost:${PORT}/api/docs`);
}

bootstrap().catch((err) => {
  console.error('Fatal error during bootstrap:', err);
  process.exit(1);
});
```

### Uso de ConfigService en Servicios

```typescript
import { Injectable } from '@nestjs/common';
import { ConfigService } from '@nestjs/config';

@Injectable()
export class UsersService {
  constructor(
    private readonly configService: ConfigService,
  ) {}

  async getUser(id: number) {
    // ✅ CORRECTO - usar ConfigService
    const dbHost = this.configService.get<string>('database.host');
    const dbPort = this.configService.get<number>('database.port');

    // ❌ INCORRECTO - nunca usar process.env directamente
    // const dbHost = process.env.DATABASE_HOST;

    // Lógica del servicio...
  }
}
```

## Estructura de Módulos

### Crear un Feature Module

```typescript
// users.module.ts
import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { UsersService } from './users.service';
import { UsersController } from './users.controller';
import { User } from './entities/user.entity';

@Module({
  imports: [
    TypeOrmModule.forFeature([User]),
  ],
  controllers: [UsersController],
  providers: [UsersService],
  exports: [UsersService], // Para usar en otros módulos
})
export class UsersModule {}
```

### Entity

```typescript
// entities/user.entity.ts
import { Entity, PrimaryGeneratedColumn, Column, CreateDateColumn, UpdateDateColumn } from 'typeorm';

@Entity('users')
export class User {
  @PrimaryGeneratedColumn()
  id: number;

  @Column({ unique: true })
  email: string;

  @Column()
  firstName: string;

  @Column()
  lastName: string;

  @Column()
  password: string; // Siempre hasheada

  @CreateDateColumn()
  createdAt: Date;

  @UpdateDateColumn()
  updatedAt: Date;
}
```

### DTOs (Data Transfer Objects)

```typescript
// dto/create-user.dto.ts
import { IsEmail, IsString, MinLength, MaxLength } from 'class-validator';
import { ApiProperty } from '@nestjs/swagger';

export class CreateUserDto {
  @ApiProperty({ description: 'Email del usuario' })
  @IsEmail()
  email: string;

  @ApiProperty()
  @IsString()
  @MinLength(2)
  @MaxLength(50)
  firstName: string;

  @ApiProperty()
  @IsString()
  @MinLength(2)
  @MaxLength(50)
  lastName: string;

  @ApiProperty()
  @IsString()
  @MinLength(8)
  password: string;
}
```

### Service

```typescript
// users.service.ts
import { Injectable, NotFoundException, ConflictException } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import * as bcrypt from 'bcrypt';
import { User } from './entities/user.entity';
import { CreateUserDto } from './dto/create-user.dto';
import { UpdateUserDto } from './dto/update-user.dto';

@Injectable()
export class UsersService {
  constructor(
    @InjectRepository(User)
    private usersRepository: Repository<User>,
  ) {}

  async create(createUserDto: CreateUserDto): Promise<User> {
    const existingUser = await this.usersRepository.findOne({
      where: { email: createUserDto.email },
    });

    if (existingUser) {
      throw new ConflictException('Email already exists');
    }

    const hashedPassword = await bcrypt.hash(createUserDto.password, 10);
    const user = this.usersRepository.create({
      ...createUserDto,
      password: hashedPassword,
    });

    return this.usersRepository.save(user);
  }

  async findOne(id: number): Promise<User> {
    const user = await this.usersRepository.findOne({
      where: { id },
    });

    if (!user) {
      throw new NotFoundException(`User #${id} not found`);
    }

    return user;
  }

  async findAll(limit = 10, offset = 0): Promise<[User[], number]> {
    return this.usersRepository.findAndCount({
      take: limit,
      skip: offset,
    });
  }

  async update(id: number, updateUserDto: UpdateUserDto): Promise<User> {
    const user = await this.findOne(id);

    if (updateUserDto.password) {
      updateUserDto.password = await bcrypt.hash(updateUserDto.password, 10);
    }

    Object.assign(user, updateUserDto);
    return this.usersRepository.save(user);
  }

  async delete(id: number): Promise<void> {
    const result = await this.usersRepository.delete(id);
    if (result.affected === 0) {
      throw new NotFoundException(`User #${id} not found`);
    }
  }
}
```

### Controller

```typescript
// users.controller.ts
import {
  Controller,
  Get,
  Post,
  Body,
  Param,
  Put,
  Delete,
  Query,
  HttpCode,
  HttpStatus,
} from '@nestjs/common';
import { ApiTags, ApiOperation, ApiResponse } from '@nestjs/swagger';
import { UsersService } from './users.service';
import { CreateUserDto } from './dto/create-user.dto';
import { UpdateUserDto } from './dto/update-user.dto';
import { User } from './entities/user.entity';

@ApiTags('users')
@Controller('users')
export class UsersController {
  constructor(private readonly usersService: UsersService) {}

  @Post()
  @ApiOperation({ summary: 'Crear nuevo usuario' })
  @ApiResponse({ status: 201, description: 'Usuario creado', type: User })
  async create(@Body() createUserDto: CreateUserDto): Promise<User> {
    return this.usersService.create(createUserDto);
  }

  @Get()
  @ApiOperation({ summary: 'Listar usuarios' })
  @ApiResponse({ status: 200, description: 'Lista de usuarios', type: [User] })
  async findAll(
    @Query('limit') limit = 10,
    @Query('offset') offset = 0,
  ): Promise<{ users: User[]; total: number }> {
    const [users, total] = await this.usersService.findAll(limit, offset);
    return { users, total };
  }

  @Get(':id')
  @ApiOperation({ summary: 'Obtener usuario por ID' })
  @ApiResponse({ status: 200, description: 'Usuario encontrado', type: User })
  async findOne(@Param('id') id: number): Promise<User> {
    return this.usersService.findOne(id);
  }

  @Put(':id')
  @ApiOperation({ summary: 'Actualizar usuario' })
  async update(
    @Param('id') id: number,
    @Body() updateUserDto: UpdateUserDto,
  ): Promise<User> {
    return this.usersService.update(id, updateUserDto);
  }

  @Delete(':id')
  @HttpCode(HttpStatus.NO_CONTENT)
  @ApiOperation({ summary: 'Eliminar usuario' })
  async delete(@Param('id') id: number): Promise<void> {
    return this.usersService.delete(id);
  }
}
```

## Testing

### Test Unitario

```typescript
// users.service.spec.ts
import { Test, TestingModule } from '@nestjs/testing';
import { getRepositoryToken } from '@nestjs/typeorm';
import { UsersService } from './users.service';
import { User } from './entities/user.entity';

describe('UsersService', () => {
  let service: UsersService;
  let mockUserRepository: any;

  beforeEach(async () => {
    mockUserRepository = {
      create: jest.fn(),
      save: jest.fn(),
      findOne: jest.fn(),
    };

    const module: TestingModule = await Test.createTestingModule({
      providers: [
        UsersService,
        {
          provide: getRepositoryToken(User),
          useValue: mockUserRepository,
        },
      ],
    }).compile();

    service = module.get<UsersService>(UsersService);
  });

  describe('create', () => {
    it('should create a new user', async () => {
      const createUserDto = {
        email: 'test@example.com',
        firstName: 'John',
        lastName: 'Doe',
        password: 'password123',
      };

      const mockUser = { id: 1, ...createUserDto };

      mockUserRepository.findOne.mockResolvedValue(null);
      mockUserRepository.create.mockReturnValue(mockUser);
      mockUserRepository.save.mockResolvedValue(mockUser);

      const result = await service.create(createUserDto);

      expect(result).toEqual(mockUser);
      expect(mockUserRepository.findOne).toHaveBeenCalled();
    });
  });
});
```

## Variables de Entorno

### .env.example

```bash
# ============================================
# ENTORNO
# ============================================
NODE_ENV=development

# ============================================
# BASE DE DATOS
# ============================================
DATABASE_HOST=postgres
DATABASE_PORT=5432
DATABASE_USER=postgres
DATABASE_PASSWORD=change_me
DATABASE_NAME=nestjs_db

# ============================================
# AUTENTICACIÓN
# ============================================
JWT_SECRET=your_super_secret_key_change_in_production
JWT_EXPIRATION_TIME=24h

# ============================================
# LOGGING
# ============================================
LOG_LEVEL=info

# ============================================
# CORS
# ============================================
CORS_ORIGIN=*

# ============================================
# MONGODB (si aplica)
# ============================================
MONGODB_URI=mongodb://localhost:27017/nestjs_db
```

## Validación de Entrada

### Instalación y Configuración

```bash
npm install class-validator class-transformer
```

### DTOs con Validación

```typescript
import { IsString, IsEmail, IsNotEmpty, MinLength, MaxLength, IsOptional } from 'class-validator';

export class CreateUserDto {
  @IsEmail()
  @IsNotEmpty()
  email: string;

  @IsString()
  @MinLength(2)
  @MaxLength(50)
  firstName: string;

  @IsString()
  @MinLength(8)
  password: string;

  @IsOptional()
  @IsString()
  role?: string;
}
```

## Autenticación JWT

### Instalación

```bash
npm install @nestjs/jwt passport passport-jwt @types/passport-jwt
```

### JWT Strategy

```typescript
// jwt.strategy.ts
import { Injectable } from '@nestjs/common';
import { PassportStrategy } from '@nestjs/passport';
import { ExtractJwt, Strategy } from 'passport-jwt';
import { ConfigService } from '@nestjs/config';

@Injectable()
export class JwtStrategy extends PassportStrategy(Strategy) {
  constructor(configService: ConfigService) {
    super({
      jwtFromRequest: ExtractJwt.fromAuthHeaderAsBearerToken(),
      ignoreExpiration: false,
      secretOrKey: configService.get<string>('auth.jwtSecret'),
    });
  }

  async validate(payload: any) {
    return { userId: payload.sub, username: payload.username };
  }
}
```

### Guard

```typescript
// jwt.guard.ts
import { Injectable } from '@nestjs/common';
import { AuthGuard } from '@nestjs/passport';

@Injectable()
export class JwtAuthGuard extends AuthGuard('jwt') {}
```

### Uso en Controller

```typescript
@UseGuards(JwtAuthGuard)
@Get('profile')
getProfile(@Request() req) {
  return req.user;
}
```

## Documentación con Swagger

### Setup (ya incluido en main.ts)

```typescript
import { SwaggerModule, DocumentBuilder } from '@nestjs/swagger';

const config = new DocumentBuilder()
  .setTitle('Mi API')
  .setDescription('Descripción de la API')
  .setVersion('1.0')
  .addBearerAuth()
  .build();

const document = SwaggerModule.createDocument(app, config);
SwaggerModule.setup('api/docs', app, document);
```

### Decoradores de Documentación

```typescript
@ApiTags('users')
@ApiOperation({ summary: 'Crear usuario' })
@ApiResponse({ status: 201, description: 'Usuario creado', type: User })
@ApiResponse({ status: 400, description: 'Datos inválidos' })
@Post()
create(@Body() createUserDto: CreateUserDto) {
  return this.usersService.create(createUserDto);
}
```

## Migraciones con TypeORM

### Crear migración

```bash
npm run typeorm -- migration:create src/database/migrations/CreateUsersTable
```

### Ejecutar migraciones

```bash
npm run typeorm -- migration:run
```

### Revertir migración

```bash
npm run typeorm -- migration:revert
```

## Checklist NestJS

- [ ] ¿ConfigModule está configurado globalmente?
- [ ] ¿Usa ConfigService en lugar de process.env?
- [ ] ¿Todos los módulos están en modules/?
- [ ] ¿Existe validación con class-validator?
- [ ] ¿DTOs están tipados correctamente?
- [ ] ¿Controllers tienen decoradores @ApiTags y @ApiOperation?
- [ ] ¿Existe endpoint /health?
- [ ] ¿Logging configurado?
- [ ] ¿Tests unitarios existen?
- [ ] ¿Variables de entorno en .env.example?
- [ ] ¿Hay autenticación si aplica?

---

## Recursos Útiles

- [Documentación oficial NestJS](https://docs.nestjs.com)
- [TypeORM Documentation](https://typeorm.io)
- [Swagger/OpenAPI](https://swagger.io)
- [Class Validator](https://github.com/typestack/class-validator)
